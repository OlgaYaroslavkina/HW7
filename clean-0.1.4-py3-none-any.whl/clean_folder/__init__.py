from clean_folder.clean import main
from clean_folder.normalize import normalize